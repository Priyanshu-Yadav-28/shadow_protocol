from launch import LaunchDescription
from launch.actions import GroupAction, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare
import os


def generate_launch_description():
    pkg_share = FindPackageShare('shadow_protocol').find('shadow_protocol')
    world_path = os.path.join(pkg_share, 'worlds', 'shadow_world.sdf')

    # Use TurtleBot3 Gazebo waffle_pi model (includes diff-drive plugin)
    tb3_gazebo_share = FindPackageShare('turtlebot3_gazebo').find('turtlebot3_gazebo')
    waffle_pi_sdf = os.path.join(
        tb3_gazebo_share,
        'models', 'turtlebot3_waffle_pi', 'model.sdf'
    )

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [FindPackageShare('gazebo_ros').find('gazebo_ros'), '/launch/gazebo.launch.py']
        ),
        launch_arguments={'world': world_path}.items(),
    )

    def spawn_robot(ns, x, y):
        return GroupAction([
            # Namespace for topics (e.g., /tb3_0/cmd_vel)
            PushRosNamespace(ns),
            # Spawn TurtleBot3 Gazebo SDF with diff-drive plugin
            Node(
                package='gazebo_ros',
                executable='spawn_entity.py',
                arguments=[
                    '-file', waffle_pi_sdf,
                    '-entity', ns,
                    '-robot_namespace', '/' + ns,
                    '-x', str(x), '-y', str(y), '-z', '0.0'
                ],
                output='screen',
            ),
        ])

    leader = spawn_robot('tb3_0', 0.0, 0.0)
    follower1 = spawn_robot('tb3_1', -1.0, 0.0)
    follower2 = spawn_robot('tb3_2', -2.0, 0.0)

    follower1_node = Node(
        package='shadow_protocol',
        executable='follower_node',
        name='follower1',
        output='screen',
        parameters=[{
            'leader_frame': 'tb3_0/base_footprint',
            'self_frame': 'tb3_1/base_footprint',
            'cmd_vel_topic': '/tb3_1/cmd_vel',
            'role': 'follower1',
        }],
    )

    follower2_node = Node(
        package='shadow_protocol',
        executable='follower_node',
        name='follower2',
        output='screen',
        parameters=[{
            'leader_frame': 'tb3_1/base_footprint',
            'self_frame': 'tb3_2/base_footprint',
            'cmd_vel_topic': '/tb3_2/cmd_vel',
            'role': 'follower2',
        }],
    )

    return LaunchDescription([
        gazebo_launch,
        leader,
        follower1,
        follower2,
        follower1_node,
        follower2_node,
    ])
