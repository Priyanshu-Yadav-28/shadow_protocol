from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os


def generate_launch_description():
    pkg_share = FindPackageShare('shadow_protocol').find('shadow_protocol')
    rviz_cfg = os.path.join(pkg_share, 'rviz', 'shadow_protocol.rviz')

    viz = Node(
        package='shadow_protocol',
        executable='visualization_node',
        name='visualization_node',
        output='screen',
    )

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_cfg],
        output='screen',
    )

    return LaunchDescription([
        viz,
        rviz,
    ])
