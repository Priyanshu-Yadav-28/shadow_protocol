from launch import LaunchDescription
from launch.actions import GroupAction, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node, PushRosNamespace
from launch_ros.substitutions import FindPackageShare
import os


def generate_launch_description():
    pkg_share = FindPackageShare('shadow_protocol').find('shadow_protocol')
    world_path = os.path.join(pkg_share, 'worlds', 'shadow_world.sdf')

    # Use official TurtleBot3 waffle_pi URDF for all robots
    tb3_desc_share = FindPackageShare('turtlebot3_description').find('turtlebot3_description')
    waffle_pi_urdf = os.path.join(tb3_desc_share, 'urdf', 'turtlebot3_waffle_pi.urdf')

    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            [FindPackageShare('gazebo_ros').find('gazebo_ros'), '/launch/gazebo.launch.py']
        ),
        launch_arguments={'world': world_path}.items(),
    )

    def spawn_robot(ns, x, y):
        urdf_path = waffle_pi_urdf
        return GroupAction([
            PushRosNamespace(ns),
            Node(
                package='robot_state_publisher',
                executable='robot_state_publisher',
                name='robot_state_publisher',
                parameters=[{'robot_description': open(urdf_path).read()}],
            ),
            Node(
                package='gazebo_ros',
                executable='spawn_entity.py',
                arguments=['-topic', 'robot_description',
                           '-entity', ns,
                           '-x', str(x), '-y', str(y), '-z', '0.0'],
                output='screen',
            ),
        ])

    leader = spawn_robot('tb3_0', 0.0, 0.0)
    follower1 = spawn_robot('tb3_1', -1.0, 0.0)
    follower2 = spawn_robot('tb3_2', -2.0, 0.0)

    keyboard = Node(
        package='shadow_protocol',
        executable='keyboard_controller',
        name='keyboard_controller',
        output='screen',
    )

    follower1_node = Node(
        package='shadow_protocol',
        executable='follower_node',
        name='follower1',
        output='screen',
        parameters=[{
            'leader_frame': 'tb3_0/base_footprint',
            'self_frame': 'tb3_1/base_footprint',
            'cmd_vel_topic': '/tb3_1/cmd_vel',
            'role': 'follower1',
        }],
    )

    follower2_node = Node(
        package='shadow_protocol',
        executable='follower_node',
        name='follower2',
        output='screen',
        parameters=[{
            'leader_frame': 'tb3_1/base_footprint',
            'self_frame': 'tb3_2/base_footprint',
            'cmd_vel_topic': '/tb3_2/cmd_vel',
            'role': 'follower2',
        }],
    )

    viz = Node(
        package='shadow_protocol',
        executable='visualization_node',
        name='visualization_node',
        output='screen',
    )

    rviz_cfg = os.path.join(pkg_share, 'rviz', 'shadow_protocol.rviz')
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_cfg],
        output='screen',
    )

    return LaunchDescription([
        gazebo_launch,
        leader,
        follower1,
        follower2,
        keyboard,
        follower1_node,
        follower2_node,
        viz,
        rviz,
    ])
