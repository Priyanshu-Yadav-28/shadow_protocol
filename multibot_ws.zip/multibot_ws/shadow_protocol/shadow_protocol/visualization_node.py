import rclpy
from rclpy.node import Node
from visualization_msgs.msg import Marker
from geometry_msgs.msg import Point
from std_msgs.msg import Float32, ColorRGBA, String

import tf2_ros
from tf2_ros import TransformException


class VisualizationNode(Node):
    def __init__(self):
        super().__init__('visualization_node')
        self.pub = self.create_publisher(Marker, '/shadow_protocol/markers', 10)

        self.safe_leader = 0.5
        self.safe_followers = 0.5
        self.mode = 'chain'

        self.sub_safe_leader = self.create_subscription(
            Float32, '/shadow_protocol/safe_distance_leader', self.cb_safe_leader, 10)
        self.sub_safe_followers = self.create_subscription(
            Float32, '/shadow_protocol/safe_distance_followers', self.cb_safe_followers, 10)
        self.sub_mode = self.create_subscription(
            String, '/shadow_protocol/formation_mode', self.cb_mode, 10)

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.timer = self.create_timer(0.1, self.update)

    def cb_safe_leader(self, msg: Float32):
        self.safe_leader = msg.data

    def cb_safe_followers(self, msg: Float32):
        self.safe_followers = msg.data

    def cb_mode(self, msg: String):
        self.mode = msg.data

    def make_sphere(self, frame_id, radius, ns, mid, color):
        m = Marker()
        m.header.frame_id = frame_id
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = ns
        m.id = mid
        m.type = Marker.SPHERE
        m.action = Marker.ADD
        m.pose.orientation.w = 1.0
        m.scale.x = radius * 2.0
        m.scale.y = radius * 2.0
        m.scale.z = 0.05
        m.color = color
        m.color.a = 0.3
        return m

    def make_line(self, frame_id, ns, mid, p1, p2, color):
        m = Marker()
        m.header.frame_id = frame_id
        m.header.stamp = self.get_clock().now().to_msg()
        m.ns = ns
        m.id = mid
        m.type = Marker.LINE_STRIP
        m.action = Marker.ADD
        m.scale.x = 0.02
        m.color = color
        m.color.a = 1.0
        m.points = [p1, p2]
        return m

    def update(self):
        color1 = ColorRGBA(r=0.0, g=1.0, b=0.0, a=0.3)
        color2 = ColorRGBA(r=0.0, g=0.0, b=1.0, a=0.3)
        line_color = ColorRGBA(r=1.0, g=1.0, b=0.0, a=1.0)

        # spheres around followers (using existing base_footprint frame)
        m1 = self.make_sphere('base_footprint', self.safe_leader, 'safe_zone', 1, color1)
        m2 = self.make_sphere('base_footprint',
                              self.safe_followers if self.mode == 'chain' else self.safe_leader,
                              'safe_zone', 2, color2)
        self.pub.publish(m1)
        self.pub.publish(m2)

        # tether lines are optional; since TF only has odom->base_footprint without tb3_* frames,
        # we skip drawing separate lines to avoid lookup errors.


def main(args=None):
    rclpy.init(args=args)
    node = VisualizationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
