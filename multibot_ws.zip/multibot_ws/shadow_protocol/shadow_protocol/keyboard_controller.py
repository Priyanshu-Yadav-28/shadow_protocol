import sys
import termios
import tty
import select

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32, String

MIN_SPEED = 0.05
MAX_SPEED = 1.0
MIN_DIST = 0.1
MAX_DIST = 1.0


class KeyboardController(Node):
    def __init__(self):
        super().__init__('keyboard_controller')
        self.pub_cmd = self.create_publisher(Twist, '/tb3_0/cmd_vel', 10)
        self.pub_safe_leader = self.create_publisher(Float32, '/shadow_protocol/safe_distance_leader', 10)
        self.pub_safe_followers = self.create_publisher(Float32, '/shadow_protocol/safe_distance_followers', 10)
        self.pub_mode = self.create_publisher(String, '/shadow_protocol/formation_mode', 10)

        self.speed = 0.2
        self.safe_leader = 0.5
        self.safe_followers = 0.5
        self.mode = 'chain'

        self.timer = self.create_timer(0.05, self.update)

        self.settings = termios.tcgetattr(sys.stdin)

    def get_key(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.05)
        key = sys.stdin.read(1) if rlist else ''
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    @staticmethod
    def clamp(v, lo, hi):
        return max(lo, min(hi, v))

    def update(self):
        twist = Twist()
        key = self.get_key()

        if key:
            k = key.lower()
            if k == 'w':
                twist.linear.x = self.speed
            elif k == 's':
                twist.linear.x = -self.speed
            elif k == 'a':
                twist.angular.z = self.speed
            elif k == 'd':
                twist.angular.z = -self.speed
            elif k == 'q':
                self.speed = self.clamp(self.speed + 0.05, MIN_SPEED, MAX_SPEED)
                self.get_logger().info(f"Speed: {self.speed:.2f}")
            elif k == 'e':
                self.speed = self.clamp(self.speed - 0.05, MIN_SPEED, MAX_SPEED)
                self.get_logger().info(f"Speed: {self.speed:.2f}")
            elif k == 'z':
                self.safe_leader = self.clamp(self.safe_leader + 0.05, MIN_DIST, MAX_DIST)
                self.get_logger().info(f"safe_distance_leader: {self.safe_leader:.2f}")
            elif k == 'x':
                self.safe_leader = self.clamp(self.safe_leader - 0.05, MIN_DIST, MAX_DIST)
                self.get_logger().info(f"safe_distance_leader: {self.safe_leader:.2f}")
            elif k == 'c':
                self.safe_followers = self.clamp(self.safe_followers + 0.05, MIN_DIST, MAX_DIST)
                self.get_logger().info(f"safe_distance_followers: {self.safe_followers:.2f}")
            elif k == 'v':
                self.safe_followers = self.clamp(self.safe_followers - 0.05, MIN_DIST, MAX_DIST)
                self.get_logger().info(f"safe_distance_followers: {self.safe_followers:.2f}")
            elif k == 't':
                self.mode = 'triangle' if self.mode == 'chain' else 'chain'
                self.get_logger().info(f"Formation mode: {self.mode}")

        # publish leader cmd_vel (if no key, twist=0 so robot stops)
        self.pub_cmd.publish(twist)

        # publish distances + mode every cycle
        m1 = Float32(); m1.data = self.safe_leader
        m2 = Float32(); m2.data = self.safe_followers
        m3 = String(); m3.data = self.mode
        self.pub_safe_leader.publish(m1)
        self.pub_safe_followers.publish(m2)
        self.pub_mode.publish(m3)


def main(args=None):
    rclpy.init(args=args)
    node = KeyboardController()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
