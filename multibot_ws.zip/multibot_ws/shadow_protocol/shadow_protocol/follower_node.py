import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from std_msgs.msg import Float32, String


class FollowerNode(Node):
    def __init__(self):
        super().__init__('follower_node')

        self.declare_parameter('cmd_vel_topic', '/tb3_1/cmd_vel')
        self.declare_parameter('role', 'follower1')

        self.role = self.get_parameter('role').get_parameter_value().string_value
        cmd_topic = self.get_parameter('cmd_vel_topic').get_parameter_value().string_value

        self.pub_cmd = self.create_publisher(Twist, cmd_topic, 10)

        self.safe_leader = 0.5
        self.safe_followers = 0.5
        self.mode = 'chain'

        self.sub_safe_leader = self.create_subscription(
            Float32, '/shadow_protocol/safe_distance_leader', self.cb_safe_leader, 10)
        self.sub_safe_followers = self.create_subscription(
            Float32, '/shadow_protocol/safe_distance_followers', self.cb_safe_followers, 10)
        self.sub_mode = self.create_subscription(
            String, '/shadow_protocol/formation_mode', self.cb_mode, 10)

        # Odometry for self and potential leaders
        if self.role == 'follower1':
            self.self_odom_topic = '/tb3_1/odom'
        else:
            self.self_odom_topic = '/tb3_2/odom'

        # Leaders: leader robot and first follower (for chain mode)
        self.leader0_odom_topic = '/tb3_0/odom'
        self.leader1_odom_topic = '/tb3_1/odom'

        self.self_odom = None
        self.leader0_odom = None
        self.leader1_odom = None

        self.create_subscription(Odometry, self.self_odom_topic, self.cb_self_odom, 10)
        self.create_subscription(Odometry, self.leader0_odom_topic, self.cb_leader0_odom, 10)
        self.create_subscription(Odometry, self.leader1_odom_topic, self.cb_leader1_odom, 10)

        self.timer = self.create_timer(0.05, self.control_loop)

        self.k_v = 0.8
        self.k_w = 2.0
        self.max_lin = 0.5
        self.max_ang = 1.5

    def cb_safe_leader(self, msg: Float32):
        self.safe_leader = msg.data

    def cb_safe_followers(self, msg: Float32):
        self.safe_followers = msg.data

    def cb_mode(self, msg: String):
        self.mode = msg.data

    def cb_self_odom(self, msg: Odometry):
        self.self_odom = msg

    def cb_leader0_odom(self, msg: Odometry):
        self.leader0_odom = msg

    def cb_leader1_odom(self, msg: Odometry):
        self.leader1_odom = msg

    def decide_target_distance(self) -> float:
        if self.role == 'follower1':
            return self.safe_leader
        else:
            if self.mode == 'chain':
                return self.safe_followers
            else:
                return self.safe_leader

    @staticmethod
    def yaw_from_quat(q):
        # Quaternion to yaw
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def control_loop(self):
        if self.self_odom is None:
            return

        # Choose leader odom based on role and mode
        if self.role == 'follower1':
            leader = self.leader0_odom
        else:
            if self.mode == 'chain':
                leader = self.leader1_odom
            else:
                leader = self.leader0_odom

        if leader is None:
            return

        sx = self.self_odom.pose.pose.position.x
        sy = self.self_odom.pose.pose.position.y
        lx = leader.pose.pose.position.x
        ly = leader.pose.pose.position.y

        dx = lx - sx
        dy = ly - sy

        d = math.hypot(dx, dy)

        # heading error in self frame
        q = self.self_odom.pose.pose.orientation
        yaw_self = self.yaw_from_quat(q)
        angle_to_leader = math.atan2(dy, dx)
        theta = angle_to_leader - yaw_self
        # normalize to [-pi, pi]
        while theta > math.pi:
            theta -= 2.0 * math.pi
        while theta < -math.pi:
            theta += 2.0 * math.pi

        target = self.decide_target_distance()
        error = d - target

        v = self.k_v * error
        w = self.k_w * theta

        if abs(error) < 0.02:
            v = 0.0

        v = max(-self.max_lin, min(self.max_lin, v))
        w = max(-self.max_ang, min(self.max_ang, w))

        twist = Twist()
        twist.linear.x = v
        twist.angular.z = w
        self.pub_cmd.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    node = FollowerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
