from setuptools import find_packages, setup

package_name = 'shadow_protocol'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', [
            'launch/start_sim.launch.py',
            'launch/gazebo_sim.launch.py',
            'launch/rviz_view.launch.py',
        ]),
        ('share/' + package_name + '/rviz', ['rviz/shadow_protocol.rviz']),
        ('share/' + package_name + '/worlds', ['worlds/shadow_world.sdf']),
        ('share/' + package_name + '/urdf', [
            'urdf/turtlebot3_burger_red.urdf.xacro',
            'urdf/turtlebot3_burger.urdf.xacro'
        ]),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ubuntu@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'keyboard_controller = shadow_protocol.keyboard_controller:main',
            'follower_node = shadow_protocol.follower_node:main',
            'visualization_node = shadow_protocol.visualization_node:main',
        ],
    },
)
